package manager;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;
import beans.Etudiant;

@Stateless
public class EtudiantManager {

    @PersistenceContext
    private EntityManager em;

    public void createEtudiant(Etudiant etudiant) {
        em.persist(etudiant);
    }

    public Etudiant getEtudiant(int id) {
        return em.find(Etudiant.class, id);
    }

    public List<Etudiant> getAllEtudiants() {
        return em.createQuery("SELECT e FROM Etudiant e", Etudiant.class).getResultList();
    }

    public Etudiant updateEtudiant(Etudiant etudiant) {
        return em.merge(etudiant);
    }

    public void deleteEtudiant(int id) {
        Etudiant etudiant = em.find(Etudiant.class, id);
        if (etudiant != null) {
            em.remove(etudiant);
        }
    }
}
