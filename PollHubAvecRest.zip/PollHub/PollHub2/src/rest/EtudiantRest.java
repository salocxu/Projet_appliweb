package rest;

import javax.ejb.EJB;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

import beans.Etudiant;
import manager.EtudiantManager;

@Path("/etudiant")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class EtudiantRest {

    @EJB
    private EtudiantManager etudiantManager;

    @POST
    @Path("/create")
    public Response createEtudiant(Etudiant etudiant) {
        etudiantManager.createEtudiant(etudiant);
        return Response.ok().build();
    }

    @GET
    @Path("/{id}")
    public Response getEtudiant(@PathParam("id") int id) {
        Etudiant etudiant = etudiantManager.getEtudiant(id);
        return Response.ok(etudiant).build();
    }

    @GET
    public Response getAllEtudiants() {
        List<Etudiant> etudiants = etudiantManager.getAllEtudiants();
        return Response.ok(etudiants).build();
    }

    @PUT
    @Path("/update")
    public Response updateEtudiant(Etudiant etudiant) {
        Etudiant updatedEtudiant = etudiantManager.updateEtudiant(etudiant);
        return Response.ok(updatedEtudiant).build();
    }

    @DELETE
    @Path("/delete/{id}")
    public Response deleteEtudiant(@PathParam("id") int id) {
        etudiantManager.deleteEtudiant(id);
        return Response.ok().build();
    }
}
